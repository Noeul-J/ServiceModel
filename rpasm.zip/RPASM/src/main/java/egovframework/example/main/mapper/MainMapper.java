package egovframework.example.main.mapper;

public class MainMapper {

}
