package egovframework.example.main.dao;

public class MainDaoImpl {

}
