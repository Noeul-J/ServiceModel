package egovframework.example.main.model;

public class MainVO {

}
