package egovframework.example.main.dao;

public class MainDao {

}
